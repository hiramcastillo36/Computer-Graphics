var searchData=
[
  ['face_0',['face',['../class_face.html',1,'Face'],['../class_face.html#a52a201f136910cc3201e3a5464cd7248',1,'Face::Face()']]],
  ['face_2ecpp_1',['Face.cpp',['../_face_8cpp.html',1,'']]],
  ['face_2eh_2',['Face.h',['../_face_8h.html',1,'']]],
  ['faces_3',['faces',['../class_object.html#a930e2a0e138690afe71201b8c4552ab7',1,'Object']]],
  ['filename_4',['fileName',['../class_object.html#aed5219de2a5260b172566ca817411614',1,'Object']]]
];
