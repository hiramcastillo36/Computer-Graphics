var searchData=
[
  ['vertex_0',['vertex',['../class_vertex.html#a97488994a2482d70da74e1b91d40e169',1,'Vertex::Vertex()'],['../class_vertex.html#a97207a234af1ae7bf05529461c9da822',1,'Vertex::Vertex(float vx, float vy, float vz)']]]
];
