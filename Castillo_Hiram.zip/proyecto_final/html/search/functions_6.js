var searchData=
[
  ['getedges_0',['getEdges',['../class_face.html#a9ea29a424c8bead4d98968502a17fb31',1,'Face']]],
  ['getfaces_1',['getFaces',['../class_object.html#aef3d9b4a4e91caed80299207ae6cff39',1,'Object']]],
  ['getprogramid_2',['getProgramID',['../class_open_g_l.html#a39d87020db31c36e3efb53c42f70cfde',1,'OpenGL']]],
  ['gettransform_3',['getTransform',['../class_utils.html#ad7e1873a67a6fbafb35db28701d69d72',1,'Utils']]],
  ['getvertices_4',['getVertices',['../class_object.html#aba723932a2b2e11297c1197a6b8d8467',1,'Object']]],
  ['getvf_5',['getVf',['../class_edge.html#af4100fb591cc0fe4a0796b253a9b90e4',1,'Edge']]],
  ['getvi_6',['getVi',['../class_edge.html#a75c9b07225f43ab021174f92b00e1931',1,'Edge']]],
  ['getx_7',['getX',['../class_vertex.html#aa78d4c3433559e6e50260240c49a3d03',1,'Vertex']]],
  ['gety_8',['getY',['../class_vertex.html#a12facdc9f554fd718e449f2aa2eefeaf',1,'Vertex']]],
  ['getz_9',['getZ',['../class_vertex.html#a258fea59f7c07f4e8784fc90c6ac7cb3',1,'Vertex']]]
];
