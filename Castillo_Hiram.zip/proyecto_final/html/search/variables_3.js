var searchData=
[
  ['faces_0',['faces',['../class_object.html#a930e2a0e138690afe71201b8c4552ab7',1,'Object']]],
  ['filename_1',['fileName',['../class_object.html#aed5219de2a5260b172566ca817411614',1,'Object']]]
];
