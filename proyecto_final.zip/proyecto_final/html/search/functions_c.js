var searchData=
[
  ['ply_0',['Ply',['../class_ply.html#a72cf68a560b691517dc1ad360c0c045a',1,'Ply']]],
  ['print_1',['print',['../class_edge.html#ab0a95bcac59d7c1bee7ff91435d156b3',1,'Edge::print()'],['../class_face.html#aba2e18d62d62b3d3545fb16f165dbd30',1,'Face::print()'],['../class_vertex.html#abc2531c8f9b2eed32478f4fba4603e88',1,'Vertex::print()']]]
];
