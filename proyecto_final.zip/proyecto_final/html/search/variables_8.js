var searchData=
[
  ['transform_0',['transform',['../class_object.html#a6b9e1c5f1dad7c7622cd5523d1a76de3',1,'Object::transform'],['../class_utils.html#a0c3c07455c75b2dd36daea1e0f2d38da',1,'Utils::transform']]],
  ['translate_1',['translate',['../class_utils.html#a06761b13367eb66d0a9ba9b06dd61a57',1,'Utils']]]
];
