var searchData=
[
  ['face_0',['Face',['../class_face.html#a52a201f136910cc3201e3a5464cd7248',1,'Face']]]
];
