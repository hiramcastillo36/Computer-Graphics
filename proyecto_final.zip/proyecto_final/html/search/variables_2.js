var searchData=
[
  ['datasize_0',['datasize',['../class_object.html#a514540d6d31ba5a450ffa3fbf3753b4f',1,'Object']]]
];
